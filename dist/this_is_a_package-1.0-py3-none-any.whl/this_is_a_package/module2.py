
def get_born_year(age):
    return 2020 - age