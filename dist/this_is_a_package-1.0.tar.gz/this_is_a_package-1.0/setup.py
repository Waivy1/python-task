from setuptools import setup

setup(
    name='this_is_a_package',
    version='1.0',
    packages=['this_is_a_package'],
    author='Vika Po'
)